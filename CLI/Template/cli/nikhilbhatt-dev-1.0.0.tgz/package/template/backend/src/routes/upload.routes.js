import express from "express";

import protect from "../middleware/authMiddleware.js";
import upload from "../middleware/uploadMiddleware.js";

import { uploadImage } from "../controllers/upload.controller.js";

const router = express.Router();

router.post("/", protect, upload.single("image"), uploadImage);

export default router;
